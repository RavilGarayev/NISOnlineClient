export default {
    hostname: 'myhostname'
 }