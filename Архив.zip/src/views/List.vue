<template>
  <div>  
    <h1>List</h1>
  </div>
</template>

<script>
export default {
  name: 'List',
  components: {
  }
}
</script>

<style lang="scss" scoped>

</style>
